<?php
// App Root
define('APPROOT', dirname(dirname(__FILE__)));
// URL Root
define('URLROOT', 'http://localhost/ashna/');
// Site Name
define('SITENAME', 'ASHNA');
